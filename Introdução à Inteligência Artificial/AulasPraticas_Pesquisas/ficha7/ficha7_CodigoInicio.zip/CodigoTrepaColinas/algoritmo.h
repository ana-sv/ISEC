int trepa_colinas(int sol[], int *mat, int vert, int num_iter);
