void evaluate(pchrom pop, struct info d, int mat[][2]);
