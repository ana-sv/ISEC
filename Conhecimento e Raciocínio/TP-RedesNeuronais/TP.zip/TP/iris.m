function [net, trFinal, accuracy, time, epochs] = iris(isToTrain, funcTreino, cam1Treino, cam2Treino, trainRatio, valRatio, testRatio, trainTool, isToTrainWithProps, isToDivideFcn, camadasEscondidas, isToPlot, redeCarregada)
disp('A rede neuronal para o reconhecimento da esp�cie vai come�ar!')
disp('Aguarde enquanto a rede neuronal est� a ser criada e configurada...')
% CRIAR E CONFIGURAR A REDE NEURONAL
% Camadas Escondidas
net = feedforwardnet(camadasEscondidas);
% INDICAR: N? camadas escondidas e nos por camada escondida //1 no
% enunciado
disp('As fun��es de treino est�o a ser configuradas...')
%net.layers{3}.transferFcn = 'purelin'; %(camada 2, pure linear)
% INDICAR: Funcao de treino: fishe{'trainlm', 'trainbfg', traingd'}
if funcTreino == 1.0
    net.trainFcn = 'trainlm';
elseif funcTreino == 2.0
    net.trainFcn = 'traingd';
else
    net.trainFcn = 'trainbfg';
end
% INDICAR: Funcoes de ativacao das camadas escondidas e de saida: {'purelin', 'logsig', 'tansig'}
% FUNCAO DE ATIVACAO DA CAMADA DE SAIDA
%aqui coloca-se o n� da camada onde se quer mexer
if cam2Treino == 6.0
    % CAMADA 1
    if cam1Treino == 1.0
        net.layers{1}.transferFcn = 'hardlim'; %(camada 1, step)
    elseif cam1Treino == 2.0
        net.layers{1}.transferFcn = 'purelin'; %(camada 1, linear)
    elseif cam1Treino == 3.0
        net.layers{1}.transferFcn = 'logsig'; %(camada 1, sigmoid)
    elseif cam1Treino == 4.0
        net.layers{1}.transferFcn = 'tansig'; %(camada 1, tanH)
    elseif cam1Treino == 5.0
        net.layers{1}.transferFcn = 'hardlims'; %(camada 1, sinal)
    end
else
    % CAMADA 1
    if cam1Treino == 1.0
        net.layers{1}.transferFcn = 'hardlim'; %(camada 1, step)
    elseif cam1Treino == 2.0
        net.layers{1}.transferFcn = 'purelin'; %(camada 1, linear)
    elseif cam1Treino == 3.0
        net.layers{1}.transferFcn = 'logsig'; %(camada 1, sigmoid)
    elseif cam1Treino == 4.0
        net.layers{1}.transferFcn = 'tansig'; %(camada 1, tanH)
    elseif cam1Treino == 5.0
        net.layers{1}.transferFcn = 'hardlims'; %(camada 1, sinal)
    end
    
    % CAMADA 2
    if cam2Treino == 1.0
        net.layers{2}.transferFcn = 'hardlim'; %(camada 2, step)
    elseif cam2Treino == 2.0
        net.layers{2}.transferFcn = 'purelin'; %(camada 2, linear)
    elseif cam2Treino == 3.0
        net.layers{2}.transferFcn = 'logsig'; %(camada 2, sigmoid)
    elseif cam2Treino == 4.0
        net.layers{2}.transferFcn = 'tansig'; %(camada 2, tanH)
    elseif cam2Treino == 5.0
        net.layers{2}.transferFcn = 'hardlims'; %(camada 2, sinal)
    end
end

disp('As percentagens da fun��o de treino, valida��o e teste est�o a ser configuradas...')
% INDICAR: Divisao dos exemplos pelos conjuntos de treino, validacao e teste
%A fun��o de divis�o por defeito (dividerand) cria os 3 conjuntos de
%treino, valida��o e teste, respetivamente, com 70%, 15% e 15% dos exemplos. Estes valores
%podem ser alterados atrav�s das vari�veis pertencentes ao objeto net.divideParam .

if isToDivideFcn == 1.0
    net.divideFcn = 'dividerand';
    net.divideParam.trainRatio = trainRatio;
    net.divideParam.valRatio = valRatio;
    net.divideParam.testRatio = testRatio;
end
disp('As imagens vetorizadas e os indicadores est�o a ser carregados...')
if isToTrainWithProps == 1.0
    load('imagesProperties.mat')
    imagesvectorized = imagesProperties;
    clear imagesProperties;
else
    load('imagesvectorized.mat')
end
load('labels.mat')
imagesvectorized=imagesvectorized';
if trainTool == 0.0
    net.trainParam.showWindow = 0;
end
% COMPLETAR A RESTANTE CONFIGURACAO

disp('A configura��o da rede neuronal foi terminada.')
% TREINAR
if isToTrain
    disp('Aguarde enquanto a rede neuronal est� a ser treinada...')
    if redeCarregada == 1 && isToTrainWithProps == 0.0
        disp('A rede com binario foi carregada com sucesso!')
        load('rede.mat')
        net = rede;
        clear rede;
    else
        if redeCarregada == 1 && isToTrainWithProps == 1.0
            disp('A rede com caracteristicas foi carregada com sucesso!')
            load('redeProps.mat')
            net = rede;
            clear rede;
        end
    end
    [net,trFinal] = train(net, imagesvectorized, labels);
else
    disp('Aguarde enquanto a rede neuronal est� a ser carregada...')
    if isToTrainWithProps == 1.0
        load('redeProps.mat')
        net = rede;
        clear rede;
        load('trProps.mat')
        trFinal = tr;
        clear tr;        
    else
        load('rede.mat')
        net = rede;
        clear rede;
        load('tr.mat')
        trFinal = tr;
        clear tr;
    end
end
%view(net);
disp('Aguarde enquanto � efetuada a simula��o do treino da rede neuronal.')
% SIMULAR
out = sim(net, imagesvectorized);

disp('Aguarde enquanto os gr�ficos est�o a ser preparados...')
%VISUALIZAR DESEMPENHO
if isToPlot == 1.0
    %plotconfusion(labels, out) % Matriz de confusao
    plotperf(trFinal)         % Grafico com o desempenho da rede nos 3 conjuntos
end
disp('Aguarde enquanto as classifica��es corretas s�o calculadas...')
%Calcula e mostra a percentagem de classificacoes corretas no total dos exemplos
r=0;
for i=1:size(out,2)               % Para cada classificacao
    [a b] = max(out(:,i));          %b guarda a linha onde encontrou valor mais alto da saida obtida
    [c d] = max(labels(:,i));  %d guarda a linha onde encontrou valor mais alto da saida desejada
    if b == d                       % se estao na mesma linha, a classificacao foi correta (incrementa 1)
        r = r+1;
    end
end
accuracy = r/size(out,2)*100;
%fprintf('Precisao total %f\n', accuracy)

disp('Aguarde enquanto � efetuada a simula��o apenas no conjunto de teste...')
if isToTrain
    % SIMULAR A REDE APENAS NO CONJUNTO DE TESTE
    TInput = imagesvectorized(:, trFinal.testInd);
    TTargets = labels(:, trFinal.testInd);
    
    out = sim(net, TInput);
    
    disp('Aguarde enquanto as classifica��es corretas no conjunto de teste s�o calculadas...')
    %Calcula e mostra a percentagem de classificacoes corretas no conjunto de teste
    r=0;
    for i=1:size(trFinal.testInd,2)               % Para cada classificacao
        [a b] = max(out(:,i));          %b guarda a linha onde encontrou valor mais alto da saida obtida
        [c d] = max(TTargets(:,i));  %d guarda a linha onde encontrou valor mais alto da saida desejada
        if b == d                       % se estao na mesma linha, a classificacao foi correta (incrementa 1)
            r = r+1;
        end
    end
    accuracy = r/size(trFinal.testInd,2)*100;
    time = trFinal.time(:,size(trFinal.time,2))/60;
    time = round(time,2);
    epochs = trFinal.num_epochs;
else
    time = -1;
    epochs = -1;
end
%fprintf('Precisao teste %f\n', accuracy)



xx = net.IW{1,:};                    % w's de todos os inputs para a camada 1
yy1 = net.LW(2,1);                  % w's entre a camada 1 e a camada 2
xx1 = net.b{1};                      % w0's (bias) da camada 1
b1 = net.b{2};                      % bias output

%fprintf('ws entre inputs e camada 1 \n');
%disp(xx);
%fprintf('ws entre camada 1 e camada 2\n');
%disp(yy1);
%fprintf('w0 s (bias) da camada 1\n');
%disp(xx1);
%fprintf('ws entre camada 2 e camada de saida \n');
%disp(b1);

% SE E PARA MELHORAR A REDE ENTAO GUARDA LOGO
if redeCarregada == 1 && isToTrain
    rede = net;
    tr = trFinal;
    if isToTrainWithProps == 1.0
        save('redeProps.mat','rede')
        save('trProps.mat','tr')
        disp('Rede guardada com sucesso!')
    else
        save('rede.mat','rede')
        save('tr.mat','tr')
        disp('Rede guardada com sucesso!')
    end
end
end
