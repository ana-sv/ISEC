function varargout = gui(varargin)
% GUI MATLAB code for gui.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui

% Last Modified by GUIDE v2.5 27-Jun-2019 16:30:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% For�ar o adicionar das subpastas aos diretorios de pesquisa
AUX1 = size(mfilename('fullpath'));
AUX2 = AUX1(2);
AUX3 = mfilename('fullpath');
AUX4 = size(mfilename);
AUX5 = AUX3( 1 :( AUX2 - AUX4(2) ) );
CURRENTPATH = AUX5;
cd(CURRENTPATH)
addpath(genpath(pwd))
setGlobalRedeCarregada(0);
% End initialization code - DO NOT EDIT


% --- Executes just before gui is made visible.
function gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui (see VARARGIN)

% Choose default command line output for gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function eTreino_Callback(hObject, eventdata, handles)
% hObject    handle to eTreino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTreino as text
%        str2double(get(hObject,'String')) returns contents of eTreino as a double


% --- Executes during object creation, after setting all properties.
function eTreino_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTreino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function eValidacao_Callback(hObject, eventdata, handles)
% hObject    handle to eValidacao (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eValidacao as text
%        str2double(get(hObject,'String')) returns contents of eValidacao as a double


% --- Executes during object creation, after setting all properties.
function eValidacao_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eValidacao (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function eTeste_Callback(hObject, eventdata, handles)
% hObject    handle to eTeste (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTeste as text
%        str2double(get(hObject,'String')) returns contents of eTeste as a double


% --- Executes during object creation, after setting all properties.
function eTeste_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTeste (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in pBVisualizar.
function pBVisualizar_Callback(hObject, eventdata, handles)
% hObject    handle to pBVisualizar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winopen('resultados.xlsx')

% --- Executes on button press in pBGravar.
function pBGravar_Callback(hObject, eventdata, handles)
% hObject    handle to pBGravar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
disp('A gravar rede no ficheiro excel');
quant = getGlobalVezesCorreu;
if quant == 0
    msgbox('N�o existem resultados para serem guardados!','Guardar resultados')
else
    % Nome do ficheiro
    nomeFicheiro = get(handles.eTFileName, 'String');
    wasNot = getGlobalTrainedGravar;
    wasNotTrained = get(handles.cBUsar, 'Value');
    if wasNotTrained == 1.0
        carregada = 'On';
        numImg = num2str(get(handles.lTotalDeImagens, 'String'));
        camadasEscondidas = '-----';
        nomeFuncao1 = '-----';
        nomeFuncao2 = '-----';
        nomeTopologia = '-----';
        treino = '-----';
        validacao = '-----';
        teste = '-----';
        tempo = '-----';
        epoch1 = '-----';
        tempo = '-----';
        acerto = num2str(get(handles.lTaxaDeAcerto, 'String'));
    else
        if wasNot == 1.0
            carregada = 'On';
        else
            carregada = 'Off';
        end
        % Camadas escondidas
        camadasEscondidas = get(handles.eTCamadas, 'String');
        % Nome da primeira funcao de ativacao
        funcao1 = get(handles.pMFuncaoAtivacao1, 'Value');
        if funcao1 == 1.0
            nomeFuncao1 = 'Step';
        elseif funcao1 == 2.0
            nomeFuncao1 = 'Linear';
        elseif funcao1 == 3.0
            nomeFuncao1 = 'Sigmoide';
        elseif funcao1 == 4.0
            nomeFuncao1 = 'TanH';
        elseif funcao1 == 5.0
            nomeFuncao1 = 'Sinal';
        end
        % Nome da segunda funcao de ativacao
        funcao2 = get(handles.pMFuncaoAtivacao2, 'Value');
        if funcao2 == 1.0
            nomeFuncao2 = 'Step';
        elseif funcao2 == 2.0
            nomeFuncao2 = 'Linear';
        elseif funcao2 == 3.0
            nomeFuncao2 = 'Sigmoide';
        elseif funcao2 == 4.0
            nomeFuncao2 = 'TanH';
        elseif funcao2 == 5.0
            nomeFuncao2 = 'Sinal';
        else
            nomeFuncao2 = 'Nenhuma';
        end
        % Nome da topologia da rede
        topologia = get(handles.pMAlgoritmoTreino, 'Value');
        if topologia == 1.0
            nomeTopologia = 'Perceptron Training Rule';
        elseif topologia == 2.0
            nomeTopologia = 'Gradient Descent';
        elseif topologia == 3.0
            nomeTopologia = 'Stochastic Approximation to Gradient Descent';
        end
        racio = get(handles.cBAtivo, 'Value');
        if racio == 1.0
            % RACIO DO TREINO
            treino = get(handles.eTTreino, 'String');
            % RACIO DA VALIDACAO
            validacao = get(handles.eTValidacao, 'String');
            % RACIO DE TESTE
            teste = get(handles.eTTeste, 'String');
        else
            treino = '-----';
            validacao = '-----';
            teste = '-----';
        end
        % NUMERO IMAGENS
        numImg = num2str(get(handles.lTotalDeImagens, 'String'));
        
        % ACERTO
        acerto = num2str(get(handles.lTaxaDeAcerto, 'String'));
        
        % Epoch
        epoch1 = num2str(getGlobalEpoch);
        % Tempo que demorou no tipo de figura
        tempoFigura = num2str(getGlobalTime);
    end
    % DESCOBRE INPUTS
    idinputs = get(handles.cBProps, 'Value');
    if idinputs == 0.0
        inputs = 'Imagem em bin�rio';
    else
        inputs = 'Caracter�sticas da imagem';
    end
    % MATRIZ COM OS DADOS TODOS PRONTA PARA ESCREVER NO EXCEL
    texto = {nomeFicheiro, carregada, inputs, camadasEscondidas, nomeFuncao1, nomeFuncao2, nomeTopologia, treino, validacao, teste, numImg, acerto, epoch1, tempoFigura};
    % PRIMEIRA P�GINA DO EXCEL
    sheet = 1;
    % ESCREVE NO EXCEL
    [num,txt] = xlsread('resultados.xlsx',sheet);
    %finaltxt = vertcat(txt, texto);
    % Acha ultima linha
    [rows, columns] = size(txt);
    if rows == 1
        rows = 2;
    end
    rows = rows +1;
    % Escrever a come�ar numa determinada c�lula
    nomeCelula = strcat('A',num2str(rows));
    xlswrite('resultados.xlsx',texto,sheet,nomeCelula)
    msgbox('Os resultados foram guardados no excel com sucesso!','Guardar resultados')
end

function setGlobalTrainedGravar(val)
global xRedeGravar
xRedeGravar = val;

function r = getGlobalTrainedGravar
global xRedeGravar
r = xRedeGravar;

function setGlobalRede(val)
global xRede
xRede = val;

function r = getGlobalRede
global xRede
r = xRede;

function setGlobalRedeTR(val)
global uRede
uRede = val;

function r = getGlobalRedeTR
global uRede
r = uRede;

function setGlobalRede2(val)
global tRede
tRede = val;

function r = getGlobalRede2
global tRede
r = tRede;

function setGlobalRede2TR(val)
global pRede
pRede = val;

function r = getGlobalRede2TR
global pRede
r = pRede;

function setGlobalName(val)
global zName
zName = val;

function r = getGlobalName
global zName
r = zName;

function r = getNomeRede
prompt = {'Introduza o nome da rede:'};
title = 'Nome da rede';
dims = [1 35];
definput = {'net'};
r = inputdlg(prompt,title,dims, definput);


function setGlobalVezesCorreu(val)
global oVezes
oVezes = val;

function r = getGlobalVezesCorreu
global oVezes
r  = oVezes;

function setGlobalTime(val)
global sTime
sTime = val;

function r = getGlobalTime
global sTime
r = sTime;

function setGlobalTime2(val)
global cTime
cTime = val;

function r = getGlobalTime2
global cTime
r = cTime;

function setGlobalEpoch(val)
global sEpoch
sEpoch = val;

function r = getGlobalEpoch
global sEpoch
r = sEpoch;

function setGlobalMaxAltura(val)
global cMax
cMax = val;

function r = getGlobalMaxAltura
global cMax
r = cMax;

function setGlobalMaxLargura(val)
global cMaxLarg
cMaxLarg = val;

function r = getGlobalMaxLargura
global cMaxLarg
r = cMaxLarg;

function setGlobalRedeCarregada(val)
global cRedeCarregada
cRedeCarregada = val;

function r = getGlobalRedeCarregada
global cRedeCarregada
r = cRedeCarregada;

function eTFileName_Callback(hObject, eventdata, handles)
% hObject    handle to eTFileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTFileName as text
%        str2double(get(hObject,'String')) returns contents of eTFileName as a double


% --- Executes during object creation, after setting all properties.
function eTFileName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTFileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pMFuncaoAtivacao1.
function pMFuncaoAtivacao1_Callback(hObject, eventdata, handles)
% hObject    handle to pMFuncaoAtivacao1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pMFuncaoAtivacao1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pMFuncaoAtivacao1


% --- Executes during object creation, after setting all properties.
function pMFuncaoAtivacao1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pMFuncaoAtivacao1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pMFuncaoAtivacao2.
function pMFuncaoAtivacao2_Callback(hObject, eventdata, handles)
% hObject    handle to pMFuncaoAtivacao2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pMFuncaoAtivacao2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pMFuncaoAtivacao2


% --- Executes during object creation, after setting all properties.
function pMFuncaoAtivacao2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pMFuncaoAtivacao2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pBTratarImagens.
function pBTratarImagens_Callback(hObject, eventdata, handles)
% hObject    handle to pBTratarImagens (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.lTaxaDeAcerto,'String','');
fn = get(handles.eTFileName,'String');
[numFiles, max_alt, max_larg] = convertImg(fn);
setGlobalMaxAltura(max_alt);
setGlobalMaxLargura(max_larg);
set(handles.lTotalDeImagens,'String',num2str(numFiles));
msgbox('As imagens est�o prontas para entrar na rede!','Converter imagens')

% --- Executes on selection change in pMAlgoritmoTreino.
function pMAlgoritmoTreino_Callback(hObject, eventdata, handles)
% hObject    handle to pMAlgoritmoTreino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pMAlgoritmoTreino contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pMAlgoritmoTreino


% --- Executes during object creation, after setting all properties.
function pMAlgoritmoTreino_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pMAlgoritmoTreino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pBCarregarRede.
function pBCarregarRede_Callback(hObject, eventdata, handles)
% hObject    handle to pBCarregarRede (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
setGlobalRedeCarregada(1);
msgbox('A rede foi carregada com sucesso!','Treinar a rede')

% --- Executes on button press in pBTreinarRede.
function pBTreinarRede_Callback(hObject, eventdata, handles)
% hObject    handle to pBTreinarRede (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.lTaxaDeAcerto,'String','');
%set(handles.tAcertoSubEspecie,'String','');
quant = getGlobalVezesCorreu;
cam1Treino = get(handles.pMFuncaoAtivacao1, 'Value');
cam2Treino = get(handles.pMFuncaoAtivacao2, 'Value');
funcTreino = get(handles.pMAlgoritmoTreino,'Value');
camadas = str2num(get(handles.eTCamadas, 'String'));
trainTool = get(handles.cBNNTrainTool, 'Value');
redeCarregada = getGlobalRedeCarregada;
justUse = get(handles.cBUsar, 'Value');
if justUse == 1.0
    isToTrain = false;
else
    isToTrain = true;
end
if isToTrain == false
    setGlobalTrainedGravar(1);
else
    setGlobalTrainedGravar(0);
end
isToTrainWithProps = get(handles.cBProps, 'Value');
isToPlot = get(handles.cBGraficos, 'Value');
isToDivideFcn = get(handles.cBAtivo, 'Value');
trainRatio = (str2double(get(handles.eTTreino,'String'))/100);
valRatio = (str2double(get(handles.eTValidacao,'String'))/100);
testRatio = (str2double(get(handles.eTTeste,'String'))/100);
%nomeRede = getGlobalName;
%nomeRede2 = strcat(nomeRede, 'subespecie');
[rede, tr, percAcerto, time1, epoch1] = iris(isToTrain, funcTreino, cam1Treino, cam2Treino, trainRatio, valRatio, testRatio, trainTool, isToTrainWithProps, isToDivideFcn, camadas, isToPlot, redeCarregada);
setGlobalRede(rede);
setGlobalRedeTR(tr);
percAcerto = round(percAcerto,2);
percAcerto = num2str(percAcerto);
percAcerto = strcat(percAcerto,'%');
set(handles.lTaxaDeAcerto,'String',percAcerto);
setGlobalTime(time1);
setGlobalEpoch(epoch1);
drawnow
%[redesub, trsub, percAcertoSub, time2, epoch2] = notIris_ss(isToTrain, funcTreino, cam1Treino, cam2Treino, trainRatio, valRatio, testRatio, trainTool, isToTrainWithProps, isToDivideFcn, camadasEscondidas, isToPlot, redeCarregada);
% percAcertoSub = round(percAcertoSub,2);
% percAcertoSub = num2str(percAcertoSub);
% percAcertoSub = strcat(percAcertoSub,'%');
% set(handles.tAcertoSubEspecie,'String',percAcertoSub);
% setGlobalRede2(redesub);
% setGlobalRede2TR(trsub);
% setGlobalTime2(time2);
% setGlobalEpoch2(epoch2);
setGlobalRedeCarregada(0);
quant = quant +1;
setGlobalVezesCorreu(quant);
drawnow
msgbox('O treino da rede foi completado!','Treinar a rede')

% --- Executes on button press in pBGuardarRede.
function pBGuardarRede_Callback(hObject, eventdata, handles)
% hObject    handle to pBGuardarRede (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
quant = getGlobalVezesCorreu;
if quant == 0
    msgbox('Nao existe nenhuma rede!','Guardar a rede')
else
    %nomeRede = getNomeRede;
    %nomeRede2 = strcat(nomeRede,'subespecie');
    rede = getGlobalRede;
    tr = getGlobalRedeTR;
%     redeSubEspecie = getGlobalRede2;
%     trSubEspecie = getGlobalRede2TR;
    trainProps = get(handles.cBProps, 'Value');
    if trainProps == 0.0
        save('rede.mat','rede')
        save('tr.mat','tr')
%         save('redeSubEspecie.mat','redeSubEspecie')
%         save('trSubEspecie.mat','trSubEspecie')
    elseif trainProps == 1.0
        save('redeProps.mat','rede')
        save('trProps.mat','tr')
%         save('redeSubEspecieProps.mat','redeSubEspecie')
%         save('trSubEspecieProps.mat','trSubEspecie')
    end
    max_alt = getGlobalMaxAltura;
    max_larg = getGlobalMaxLargura;
    matriz_maior = [max_alt; max_larg];
    save('maxMatrice.mat','matriz_maior')
    msgbox('A rede foi guardada com sucesso!','Guardar a rede')
end

function eTCamadas_Callback(hObject, eventdata, handles)
% hObject    handle to eTCamadas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTCamadas as text
%        str2double(get(hObject,'String')) returns contents of eTCamadas as a double


% --- Executes during object creation, after setting all properties.
function eTCamadas_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTCamadas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in cBNNTrainTool.
function cBNNTrainTool_Callback(hObject, eventdata, handles)
% hObject    handle to cBNNTrainTool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cBNNTrainTool

% --- Executes on button press in cBAtivo.
function cBAtivo_Callback(hObject, eventdata, handles)
% hObject    handle to cBAtivo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cBAtivo

function eTTeste_Callback(hObject, eventdata, handles)
% hObject    handle to eTTeste (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTTeste as text
%        str2double(get(hObject,'String')) returns contents of eTTeste as a double

% --- Executes during object creation, after setting all properties.
function eTTeste_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTTeste (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function eTValidacao_Callback(hObject, eventdata, handles)
% hObject    handle to eTValidacao (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTValidacao as text
%        str2double(get(hObject,'String')) returns contents of eTValidacao as a double

% --- Executes during object creation, after setting all properties.
function eTValidacao_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTValidacao (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function eTTreino_Callback(hObject, eventdata, handles)
% hObject    handle to eTTreino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of eTTreino as text
%        str2double(get(hObject,'String')) returns contents of eTTreino as a double


% --- Executes during object creation, after setting all properties.
function eTTreino_CreateFcn(hObject, eventdata, handles)
% hObject    handle to eTTreino (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in cBProps.
function cBProps_Callback(hObject, eventdata, handles)
% hObject    handle to cBProps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cBProps

% --- Executes on button press in cBGraficos.
function cBGraficos_Callback(hObject, eventdata, handles)
% hObject    handle to cBGraficos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cBGraficos

% --- Executes on button press in cBUsar.
function cBUsar_Callback(hObject, eventdata, handles)
% hObject    handle to cBUsar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cBUsar
