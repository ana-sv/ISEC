// Programação Orientada a Objectos 2020/2021
// Ana Rita Videira - 5012012218


#include "Jogo.h"
using namespace std;


int main(int argc, char** argv) {
    
    srand(time(0));
    
    Jogo j; 
    j.startGame();
   

    return 0;
}

