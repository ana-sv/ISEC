// Programação Orientada a Objectos 2020/2021
// Ana Rita Videira - 5012012218

#include "Ilha.h"

Ilha::Ilha() {
    pontosVitoria=2;
}

Ilha::Ilha(const Ilha& orig) {
}

Ilha::~Ilha() {
}

