// Programação Orientada a Objectos 2020/2021
// Ana Rita Videira - 5012012218

#include "MisseisTeleguiados.h"

MisseisTeleguiados::MisseisTeleguiados() {
    designacao = "Misseis Teleguiados";
    ident = "misseis";
    custo = 4;
    accao = "[ * ] Imperio pode agora tentar adquirir ilhas! ";
}

MisseisTeleguiados::MisseisTeleguiados(const MisseisTeleguiados& orig) {
}

MisseisTeleguiados::~MisseisTeleguiados() {
    
}

