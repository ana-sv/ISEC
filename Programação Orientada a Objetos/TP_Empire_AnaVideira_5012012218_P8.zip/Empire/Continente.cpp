// Programação Orientada a Objectos 2020/2021
// Ana Rita Videira - 5012012218

#include "Continente.h"

Continente::Continente() {
    pontosVitoria=1;
}

Continente::Continente(const Continente& orig) {
}

Continente::~Continente() {
}

