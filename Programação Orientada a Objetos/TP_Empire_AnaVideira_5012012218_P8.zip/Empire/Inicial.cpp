// Programação Orientada a Objectos 2020/2021
// Ana Rita Videira - 5012012218


#include "Inicial.h"

Inicial::Inicial() {
    designacao = "inicial";
    resistencia = 9;
    qtProdutosCria = 1;
    qtOuroCria = 1;
    pontosVitoria = 0;
    conquistado = true;
}

Inicial::Inicial(const Inicial& orig) {
}

Inicial::~Inicial() {
}

void Inicial::update( int turno ){
    
    // nada aqui 


}